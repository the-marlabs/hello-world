import streamlit as st

if st.button("Say hello"):
    st.write("Why hello there")
else:
    st.write("Goodbye")
