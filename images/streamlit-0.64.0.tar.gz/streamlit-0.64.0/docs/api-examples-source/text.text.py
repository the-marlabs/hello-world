import streamlit as st

st.text("This is some text.")
