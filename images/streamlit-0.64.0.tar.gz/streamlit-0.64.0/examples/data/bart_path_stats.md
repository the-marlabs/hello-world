# BART statistics

## Data source

https://github.com/uber-common/deck.gl-data/blob/master/website/bart-segments.json

## Changes

* Replaced `from`/`to` blocks with `lat`, `lon`, `lat2`, `lon2`.
